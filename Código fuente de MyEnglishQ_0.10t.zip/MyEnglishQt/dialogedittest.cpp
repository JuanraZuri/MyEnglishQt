/*
  MyEnglishQt Copyright © 2019 Juanra Goti

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QMessageBox>
#include <QFileDialog>
#include <QStandardPaths>
#include <QSqlQuery>
#include <QClipboard>
#include <QKeyEvent>
#include <QShortcut>
#include <QObject>
#include <QTextStream>

#include "dialogedittest.h"
#include "ui_dialogedittest.h"

DialogEditTest::DialogEditTest(QString fileTest, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogEditTest)
{
    ui->setupUi(this);
    setWindowTitle( QCoreApplication::applicationName() );
    setWindowFlags(Qt::Window);

    setModal(true);

    // create shortcut
     QShortcut *shortcut = new QShortcut(QKeySequence(Qt::ALT + Qt::Key_1), this);
     QObject::connect( shortcut, &QShortcut::activated, this, &DialogEditTest::funImport );

    ui->tableView->setStyleSheet("QTableView:item:selected {background-color: #3399FF; color: #FFFFFF}\n"
                                 "QTableView:item:selected:focus {background-color: #3399FF;}");

    fileNameTest = fileTest;

    funConnectBD();
    funShow();
}

DialogEditTest::~DialogEditTest()
{
    delete model;
    delete ui;
}

void DialogEditTest::funConnectBD()
{
    base.removeDatabase("my_connection_name");
    base = QSqlDatabase::addDatabase("QSQLITE", "my_connection_name");
    base.setDatabaseName(fileNameTest);

    if(!base.open()){
        QMessageBox::warning(this, QCoreApplication::applicationName(), tr("Error en la conexión con la base de datos"));
        base.close();
        return;
    }
}

void DialogEditTest::funShow()
{
    model = new QSqlTableModel(nullptr, base);
    model->setTable("words");
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    model->select();

    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Índice"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Inglés"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Español"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Imagen"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("Sonido"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("Avances"));

    ui->tableView->setModel(model);
    ui->tableView->hideColumn(0);
    //ui->tableView->hideColumn(5);
    ui->tableView->setColumnWidth(1, (this->width() / 2) - 90);
    ui->tableView->setColumnWidth(2, (this->width() / 2) - 90);
    ui->tableView->setColumnWidth(3, 80);
    ui->tableView->setColumnWidth(4, 80);

    ui->tableView->verticalHeader()->hide();

    funCreateButtonsImage();
    funCreateButtonsSound();
}

QString DialogEditTest::funGetFileName(bool image)
{
    QString fileName = "";
    if(image){
        QString folderImage = QStandardPaths::writableLocation(QStandardPaths::DownloadLocation);
        fileName = QFileDialog::getOpenFileName(this,
            tr("Abrir Imagen"), folderImage, tr("Image Files (*.png *.jpg *.bmp)"));
    } else {
        QString folderSound = QStandardPaths::writableLocation(QStandardPaths::DownloadLocation);
        fileName = QFileDialog::getOpenFileName(this,
            tr("Abrir Sonido"), folderSound, tr("Sound Files (*.mp3)"));
    }
    return fileName;
}

void DialogEditTest::funCreateButtonsImage()
{
    for(int c = 0; c < model->rowCount(); c++){
        QPushButton *button = new QPushButton("...");
        button->setStyleSheet("border: 0px solid black; background: white");
        ui->tableView->setIndexWidget(ui->tableView->model()->index(c, 3), button);
        connect (button, SIGNAL(clicked()), this, SLOT(funSlotButtonsImage()));
    }
}

void DialogEditTest::funSlotButtonsImage()
{
    QString fileName = funGetFileName(true);
    if(!fileName.isEmpty()){

        QModelIndex index = ui->tableView->selectionModel()->currentIndex();
        int value = model->index(index.row(), 0).data().toInt();

        QFile file(fileName);
        if (!file.open(QIODevice::ReadOnly)) return;
        QByteArray byteArray = file.readAll();

        QSqlQuery query(base);
        query.prepare("UPDATE words SET image=:my_image WHERE ind=:my_ind");
        query.bindValue(":my_ind", QString::number(value));
        query.bindValue(":my_image", byteArray);
        query.exec();

        query.clear();
        query.finish();

        model->submitAll();

        funConnectBD();
        funShow();
    }
}

void DialogEditTest::funCreateButtonsSound()
{
    for(int c = 0; c < model->rowCount(); c++){
        QPushButton *button = new QPushButton("...");
        button->setStyleSheet("border: 0px solid black; background: white");
        ui->tableView->setIndexWidget(ui->tableView->model()->index(c, 4), button);
        connect (button, SIGNAL(clicked()), this, SLOT(funSlotButtonsSound()));
    }
}

void DialogEditTest::funSlotButtonsSound()
{
    QString fileName = funGetFileName(false);
    if(!fileName.isEmpty()){

        QModelIndex index = ui->tableView->selectionModel()->currentIndex();
        int value = model->index(index.row(), 0).data().toInt();

        QFile file(fileName);
        if (!file.open(QIODevice::ReadOnly)) return;
        QByteArray byteArray = file.readAll();

        QSqlQuery query(base);
        query.prepare("UPDATE words SET sound=:my_sound WHERE ind=:my_ind");
        query.bindValue(":my_ind", QString::number(value));
        query.bindValue(":my_sound", byteArray);
        query.exec();

        query.clear();
        query.finish();

        model->submitAll();

        funConnectBD();
        funShow();
    }
}

void DialogEditTest::on_pushButtonSaveAndExit_clicked()
{
    //Guardamos todos los cambios.
    model->submitAll();
    DialogEditTest::close();
}

void DialogEditTest::on_DialogEditTest_rejected()
{
   on_pushButtonSaveAndExit_clicked();
}

void DialogEditTest::on_pushButtonAddRow_clicked()
{
    QSqlQuery query( base );
    query.prepare("INSERT INTO words (english, spanish, image, sound, avances) "
                 "VALUES (?, ?, ?, ?, ?)");
    query.addBindValue("");
    query.addBindValue("");
    query.addBindValue("");
    query.addBindValue("");
    query.addBindValue(0);
    query.exec();

    model->submitAll();

    funConnectBD();
    funShow();
}

void DialogEditTest::on_pushButtonRemoveRow_clicked()
{
    const int row = model->rowCount();
    if( row > 1 ){
        int indSelected = ui->tableView->selectionModel()->currentIndex().row();        
        if( indSelected == -1 ){
            QMessageBox::warning( this, QCoreApplication::applicationName(), tr( "Debe de seleccionar la fila a eliminar" ));
            return;
        } else {
            ui->tableView->selectRow( indSelected );

            QMessageBox msgBox;
            msgBox.setText("Delete selected row?");
            msgBox.setStandardButtons( QMessageBox::Yes | QMessageBox::No );
            msgBox.setDefaultButton( QMessageBox::No );
            int ret = msgBox.exec();
            if( ret == QMessageBox::Yes ){
                QString indToDelete = model->index( indSelected , 0 ).data().toString();

                QSqlQuery query( base );
                query.prepare( "DELETE FROM words WHERE ind = ?" );
                query.addBindValue( indToDelete );
                query.exec();

            } else {
                return;
            }
        }
    } else {
        QMessageBox::warning(this, QCoreApplication::applicationName(), tr("No se puede eliminar la fila seleccionada. Debe de haber al menos una"));
        return;
    }

    model->submitAll();

    funConnectBD();
    funShow();
}

void DialogEditTest::resizeEvent(QResizeEvent *e)
{
    ui->tableView->setColumnWidth(1, (this->width() / 2) - 90);
    ui->tableView->setColumnWidth(2, (this->width() / 2) - 90);
    ui->tableView->setColumnWidth(3, 80);
    ui->tableView->setColumnWidth(4, 80);
}

void DialogEditTest::on_pushButtonCopy_clicked()
{
   QStringList list ;
   bool par = true, thereIsSelected = false;
   QString cadSeparador;
   foreach (const QModelIndex& index, ui->tableView->selectionModel()->selectedIndexes()){
       thereIsSelected = true;
       if(par){
           cadSeparador = "\t";
           par = false;
       } else {
           cadSeparador = "\n";
           par = true;
       }
      list << index.data().toString() << cadSeparador;
    }

   if( !thereIsSelected )
       QMessageBox::warning(this, QCoreApplication::applicationName(),
                            tr("No hay celdas seleccionadas para copiar")
                            );

   QApplication::clipboard()->setText(list.join(""));
}

void DialogEditTest::funImport()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Abrir archivo de texto para copiar"),
                                                     QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation),
                                                     tr("Text (*.txt)"));
    if( !fileName.isEmpty() ){
        QFile file( fileName );
        if ( !file.open( QIODevice::ReadOnly | QIODevice::Text ) ){
            QMessageBox::warning(this, QCoreApplication::applicationName(), tr("Error text file"));
            return;
        }

        QMessageBox::warning(this, QCoreApplication::applicationName(), tr("El proceso de importación ha comenzado.\n"
                                                                           "Dependiendo del tamaño del archivo, el tiempo resultante variará"));
        ui->pushButtonCopy->setEnabled( false );
        ui->pushButtonAddRow->setEnabled( false );
        ui->pushButtonRemoveRow->setEnabled( false );
        ui->pushButtonSaveAndExit->setEnabled( false );
        ui->tableView->setEnabled( false );

        QTextStream in( &file );
        QString line;
        QStringList listEnglish, listSpanish;
        bool par = false;
        while ( !in.atEnd() ) {
             line = in.readLine();
             if ( par ){
                 listSpanish << line;
                 par = false;
             } else {
                 listEnglish << line;
                 par = true;
             }
        }
        file.close();

        QSqlQuery query( base );
        for ( int a = 0; a < listEnglish.size(); a++ ){
            query.prepare("INSERT INTO words (english, spanish, image, sound, avances) "
                         "VALUES (?, ?, ?, ?, ?)");
            query.addBindValue( listEnglish.at( a ) );
            query.addBindValue( listSpanish.at( a ) );
            query.addBindValue("");
            query.addBindValue("");
            query.addBindValue(0);
            query.exec();
        }
        model->submitAll();

        ui->pushButtonCopy->setEnabled( true );
        ui->pushButtonAddRow->setEnabled( true );
        ui->pushButtonRemoveRow->setEnabled( true );
        ui->pushButtonSaveAndExit->setEnabled( true );
        ui->tableView->setEnabled( true );
        QMessageBox::warning(this, QCoreApplication::applicationName(), tr("La importación del archivo de texto ha concluido"));

        ui->tableView->repaint();
    }
}



