/*
  MyEnglishQt Copyright © 2019 Juanra Goti

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QFile>
#include <QMessageBox>
#include <QTextStream>

#include "dialoghelp.h"
#include "ui_dialoghelp.h"

DialogHelp::DialogHelp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogHelp)
{
    ui->setupUi(this);
    setWindowTitle(QCoreApplication::applicationName());
    setWindowFlags(Qt::Window);

    QString fileName = QCoreApplication::applicationDirPath()  + "\\MyEnglishQt.htm";

    QFile file( fileName );
    if ( !file.open( QFile::ReadOnly | QFile::Text ) ){
        QMessageBox::warning(this, QCoreApplication::applicationName(), tr("Error open file"));
        return;
    }
    QTextStream in( &file );
    ui->textEdit->setHtml( in.readAll() );
    file.close();
}

DialogHelp::~DialogHelp()
{
    delete ui;
}

void DialogHelp::on_pushButtonExit_clicked()
{
    close();
}
