﻿/*
  MyEnglishQt Copyright © 2019 Juanra Goti

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QFileDialog>
#include <QStandardPaths>
#include <QMessageBox>
#include <QSqlQuery>
#include <QDir>
#include <QFileInfo>
#include <QInputDialog>
#include <QDesktopServices>

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialogedittest.h"
#include "dialogexamen.h"
#include "dialogalfabeto.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle(QCoreApplication::applicationName());
    setWindowFlags(Qt::Window);

    miPath = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + "\\MyEnglishQt\\";
    miPath = QDir(miPath).toNativeSeparators(miPath);

    if(!QDir(miPath).exists())
        QDir().mkdir(miPath);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButtonNew_clicked()
{

    /*
        Cada lección está compuesta de 2 archivos:
        x.phr       Base de datos de las frases
        x.iphr      Archivo de texto con el índice del últimos registro mostrado en examen
    */

    bool ok;
    QString text = QInputDialog::getText( this, QCoreApplication::applicationName(),
                                          tr("Introduzca el título:"),
                                          QLineEdit::Normal, "", &ok);
    if ( ok && !text.isEmpty() ){

        QString fileBDTestG = miPath + text + ".phr";

        if( QFile( fileBDTestG ).exists() )
            QMessageBox::warning( this, QCoreApplication::applicationName(), tr("El título introducido ya existe. Introduzca otro.") );
        else {          

            QFileInfo infoFile(fileBDTestG);

            QString fileBDLastQuestionG = infoFile.path() + "/" + infoFile.baseName() + ".iphr";
            QFile fileG( fileBDLastQuestionG );
            if ( !fileG.open( QIODevice::WriteOnly | QIODevice::Text ) ){
                QMessageBox::warning(this, QCoreApplication::applicationName(), tr("Error al crear el archivo índice de los exámenes"));
                return;
            }
            QTextStream outG( &fileG );
            outG << 0 << "\n";
            fileG.close();

            baseTestG.removeDatabase("my_conection_name");
            baseTestG = QSqlDatabase::addDatabase("QSQLITE", "my_conection_name");
            baseTestG.setDatabaseName( fileBDTestG );
            if (!baseTestG.open()){
                QMessageBox::warning(this, QCoreApplication::applicationName(), tr("Error en la conexión con la base de datos"));
                baseTestG.close();
                return;
            }
            QSqlQuery queryG(baseTestG);
            queryG.exec("CREATE TABLE words ("
                       "ind  INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE NOT NULL,"
                       "english VARCHAR(200),"
                       "spanish VARCHAR(200),"
                       "image BLOB,"
                       "sound BLOB,"
                       "avances INTEGER)"
                       );
            //Se crea una base de datos con 1 elemento
            queryG.prepare("INSERT INTO words (ind, english, spanish, image, sound, avances) "
                         "VALUES (?, ?, ?, ?, ?, ?)");
            queryG.addBindValue(1);
            queryG.addBindValue("");
            queryG.addBindValue("");
            queryG.addBindValue("");
            queryG.addBindValue("");
            queryG.addBindValue(0);
            queryG.exec();

            DialogEditTest det( fileBDTestG );
            det.setModal(true);
            det.exec();
        }
    }
}

void MainWindow::on_pushButtonExanGrammar_clicked()
{
    QString fileTest = QFileDialog::getOpenFileName( this, tr( "Examen" ), miPath, "Files (*.phr)" );
    if(fileTest.isEmpty())
        return;

    //Comprobar que la base de datos no esté vacía o con todos sus elementos en el cajón número 5, ya sabidos
    QSqlDatabase base;
    base.removeDatabase( "myConnectionName" );
    base = QSqlDatabase::addDatabase( "QSQLITE", "myConnectionName" );
    base.setDatabaseName( fileTest );

    if( !base.open() ){
        QMessageBox::warning( this, QCoreApplication::applicationName(), tr("Error en la conexión con la base de datos") );
        base.close();
        return;
    }

    QSqlQuery query( "SELECT * FROM words WHERE avances < 5", base );
    int numRecords = 0;
    while( query.next() )
        numRecords++;

    if ( numRecords == 0 ){
        QMessageBox::warning(this, QCoreApplication::applicationName(), tr("El archivo está vacío o se han estudiado todas sus fichas"));
        return;
    }

    QFileInfo infoFile(fileTest);
    QString fileLastQuestion = infoFile.path() + "/" + infoFile.baseName() + ".iphr";

    DialogExamen de( fileTest, fileLastQuestion );
    de.setModal( true );
    de.exec();
}

void MainWindow::on_pushButtonEditGrammar_clicked()
{
    QString fileTest = QFileDialog::getOpenFileName( this, tr( "Editar" ), miPath, "Files (*.phr)" );
    if(fileTest.isEmpty())
        return;

    DialogEditTest det( fileTest );
    det.setModal(true);
    det.exec();
}

void MainWindow::on_pushButtonAlfabeto_clicked()
{
    DialogAlfabeto miDialogAlfabeto(this);
    miDialogAlfabeto.setModal(true);
    miDialogAlfabeto.exec();
}

void MainWindow::on_pushButtonExit_clicked()
{
    QCoreApplication::exit();
}

void MainWindow::on_pushButtonAbout_clicked()
{
    QString msg = "MyEnglishQt Copyright © 2019 Juanra Goti\n\n"

            "Version: " + QCoreApplication::applicationVersion() + "\n\n"

            "Email: juanra.uno@gmail.com\n\n"

            "https:\\\\github.com\\JuanraZuri\\MyEnglishQt\n\n"

            "This program is free software: you can redistribute it and/or modify\n"
            "it under the terms of the GNU General Public License as published by\n"
            "the Free Software Foundation, either version 3 of the License, or\n"
            "(at your option) any later version.\n\n"

            "This program is distributed in the hope that it will be useful,\n"
            "but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
            "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
            "GNU General Public License for more details.\n\n"

            "You should have received a copy of the GNU General Public License\n"
            "along with this program.  If not, see <http://www.gnu.org/licenses/>.\n\n"

            "Icons made by Freepik from www.flaticon.com\n";

    QMessageBox::information(this, QCoreApplication::applicationName(), msg);

    QString fileName = QCoreApplication::applicationDirPath()  + "/license.pdf";
    QDesktopServices::openUrl(QUrl::fromLocalFile(fileName));
}


void MainWindow::on_pushButtonHelp_clicked()
{
    QString fileName = QCoreApplication::applicationDirPath()  + "/MyEnglishQt.pdf";
    QDesktopServices::openUrl(QUrl::fromLocalFile(fileName));
}
