/*
  MyEnglishQt Copyright © 2019 Juanra Goti

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QStandardPaths>
#include <QMessageBox>
#include <QPixmap>
#include <QBuffer>
#include <QFile>
#include <QDir>
#include <QRandomGenerator>

#include "dialogexamen.h"
#include "ui_dialogexamen.h"

DialogExamen::DialogExamen(QString fileTest, QString miFileLastQuestion,  QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogExamen)
{
    ui->setupUi(this);
    setWindowTitle( QCoreApplication::applicationName() );
    setWindowFlags(Qt::Window);
    showMaximized();

    setModal(true);    

    fileNameTest = fileTest;
    fileLastQuestion = miFileLastQuestion;

    player = new QMediaPlayer(this);

    base.removeDatabase("my_connection_name");
    base = QSqlDatabase::addDatabase("QSQLITE", "my_connection_name");
    base.setDatabaseName(fileNameTest);

    if(!base.open()){
        QMessageBox::warning(this, QCoreApplication::applicationName(), tr("Error en la conexión con la base de datos"));
        base.close();
        return;
    }

    query = new QSqlQuery("SELECT * FROM words WHERE avances < 5", base);
    int numRecords = 0;
    while( query->next() )
        numRecords++;

    query->seek( 0 );

    funLoadIndexLastQuestion();
    if( indice >= numRecords )
        indice = 0;

    if( indice > 0 ){
        QMessageBox msgBox;
        msgBox.setText( tr( "¿Quiere continúar desde la última ficha?" ) );
        msgBox.setStandardButtons( QMessageBox::Yes | QMessageBox::No );
        msgBox.setDefaultButton( QMessageBox::Yes );
        int ret = msgBox.exec();
        switch ( ret ) {
        case QMessageBox::Yes:
           query->seek( indice );
           break;
        case QMessageBox::No:
           indice = 0;
           break;
        }
    }

    funShowFicha();
}

DialogExamen::~DialogExamen()
{
    delete query;
    base.commit();
    base.transaction();
    base.connectionName().clear();    
    base.close();
    delete ui;
}

void DialogExamen::funLoadIndexLastQuestion()
{
    QFile file( fileLastQuestion );
    if ( !file.open( QIODevice::ReadOnly | QIODevice::Text ) ){
        QMessageBox::warning(this, QCoreApplication::applicationName(), tr("Error index file"));
        return;
    }
    QTextStream in( &file );
    indice = in.readLine().toInt();
    file.close();
}

void DialogExamen::funSaveIndexLastQuestion()
{
    QFile file( fileLastQuestion );
    if ( !file.open( QIODevice::WriteOnly | QIODevice::Text ) ){
        QMessageBox::warning(this, QCoreApplication::applicationName(), tr("Error index file"));
        return;
    }
    QTextStream out( &file );
    if( indice > 0)
        indice--;
    out << indice;
    file.close();
}

void DialogExamen::funSound()
{
    //Si hay un sonido previo lo eliminamos
    player->setMedia(QMediaContent());
    arraySound = query->value(4).toByteArray();
    QBuffer *buffer = new QBuffer(player);
    buffer->setData(arraySound);
    buffer->open(QIODevice::ReadOnly);
    player->setMedia(QMediaContent(), buffer);
    player->setVolume(50);
    player->play();
}

void DialogExamen::funShowFicha()
{
    indice++;

    ui->labelAnswerOk->clear();

    QString question;
    //Generamos un número aleatorio entre 1 y 2
     int in = QRandomGenerator::global()->bounded(1, 3);
     if( in == 1 ){
         question = query->value(2).toString();
         answer = query->value(1).toString();
     } else {
         question = query->value(1).toString();
         answer = query->value(2).toString();
     }
     ui->labelPalabraWord->setText(question);

    if(!query->value(4).toByteArray().isEmpty())
        arraySound = query->value(4).toByteArray();

    ui->label->clear();
    if( !query->value(3).toByteArray().isEmpty() ){
        QByteArray array = query->value(3).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(array);
        pixmap = pixmap.scaled(ui->label->size(), Qt::IgnoreAspectRatio);
        ui->label->setPixmap(pixmap);
    }

    if(!arraySound.isEmpty())
        funSound();

    ui->labelAnswerOk->clear();

    ui->pushButtonEsay->setEnabled( false );
    ui->pushButtonDificult->setEnabled( false );
    ui->pushButtonCheck->setEnabled( true );
    ui->pushButtonCheck->setFocus();
}

void DialogExamen::on_pushButtonExit_clicked()
{
    base.close();
    funSaveIndexLastQuestion();
    close();
}

void DialogExamen::on_pushButtonCheck_clicked()
{
    ui->labelAnswerOk->setText( answer );

    ui->pushButtonCheck->setEnabled( false );
    ui->pushButtonDificult->setEnabled( true );
    ui->pushButtonEsay->setEnabled( true );
    ui->pushButtonEsay->setFocus();
}

void DialogExamen::funNext()
{
    if( query->next() ) {
        funShowFicha();
    } else {
        QMessageBox::information(this, QCoreApplication::applicationName(), tr("Hemos llegado al final del archivo"));
        indice = 0;
        funSaveIndexLastQuestion();
        DialogExamen::close();
    }
}

void DialogExamen::on_pushButtonSound_clicked()
{
    funSound();
}

void DialogExamen::on_pushButtonDificult_clicked()
{
    funSaveAvances( 0 );
    funNext();
}

void DialogExamen::on_pushButtonEsay_clicked()
{
    funSaveAvances( 1 );
    funNext();
}

void DialogExamen::funSaveAvances( int avancesDificultOrEasy )
{
    //Hay cinco cajas, de 1 a 5. Cada vez que "vemos" la ficha, y la marcamos como fácil, se avanza una caja. Cuando se llegue a la caja cinco se supone que sabemos la ficha
    //después de haberla "visto" 4 veces y haberla marcado esas cuatro veces como fácil. Si, en algún momento del recorrido, marcamos la ficha como difícil, se vuelve a la
    //casilla de salida: Caja 0 para ir a la 1.

    int result, cajaActual = query->value( 5 ).toInt(), indiActual = query->value( 0 ).toInt();

    //Si la ficha se marca como difícil se vuelve a la casilla 0, la casilla de salida
    if( avancesDificultOrEasy == 0 ) {
        result = 0;
    //Si la ficha se marca como fácil, se avanza una casilla: Casilla actual más una
    } else {
        //Cuando se llega a la casilla cinco, la ficha se supone que se sabe y ya no vuelve a presentarse
        if ( cajaActual == 5 || cajaActual > 5 )
            result = 5;
        else
            result = cajaActual + avancesDificultOrEasy;
    }

    QSqlQuery queryLocal( base );
    queryLocal.prepare( "UPDATE words SET avances=:my_avances WHERE ind=:my_ind" );
    queryLocal.bindValue( ":my_ind", indiActual );
    queryLocal.bindValue( ":my_avances", result );
    queryLocal.exec();
    queryLocal.clear();

    base.transaction();
    base.commit();
}
